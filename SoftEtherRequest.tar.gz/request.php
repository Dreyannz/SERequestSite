<?php
$random_number=intval( "0" . rand(1,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) );
$filename = 'account_request.sh';

		$server= '
			<html lang="en">
			<head>
				<title>SoftEther Request</title>
				<link rel="shortcut icon" type="image/x-icon" href="/logo.png" height="200" width"200">
				<meta charset="UTF-8">
				<meta name="author" content="_Dreyannz_">
				<meta name="viewport" content="width=device-width, initial-scale=1">	
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/css/bootstrap.min.css">
				<link rel="stylesheet" type="text/css" href="//use.fontawesome.com/releases/v5.0.10/css/all.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/hamburgers/0.9.3/hamburgers.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/animsition/4.0.2/css/animsition.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-css/1.4.6/select2-bootstrap.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.min.css">
				<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.18.0/sweetalert2.min.css">
				<link rel="stylesheet" type="text/css" href="//ninjacdn.siteph.net/login/v1/css/util.css">
				<link rel="stylesheet" type="text/css" href="//ninjacdn.siteph.net/login/v1/css/main.css">
				<script src="//cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.18.0/sweetalert2.all.js"></script>
			</head>
			<body>
				<div class="container-login100">
					<div class="wrap-login100">
						<div class="panel-heading p-b-48" align="center">
							<h4 class="panel-title">
								<img src="/logo.png" height="200" width"200" />
							</h4>
						</div>
						<form align="center">
							<div class="form-group">
								Host Name: CHANGE_ME_IP
							</br>
								Port/s: 443, 53, 5555
							</br>
								Virtual Hub Name: CHANGE_ME_VHUB
							</br>
								SoftEther Username: '.$_POST['se_username']."\n".'
							</br>
								SoftEther Password: '.$_POST['se_password']."\n".'
							</br></br>
								Account Valid For 5 Days Only
							</br></br>
								SoftEther Code 2 Error Fixer
							</br>
								<a href="/SE_Fixer.exe"> Download Now</a>
							</br></br>
								All Rights Reserved. 
							</br>
								<a href="https://www.LCSoftEther.ml">_Dreyannz_ AutoScripts</a>
							</div>
						</form>
					</div>
				</div>
			</body>
			</html>'. PHP_EOL; 
	file_put_contents('my_account_'.$random_number.'.html', $server);

	if (file_exists($filename))
		{
			$account_request= '${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserCreate '.$_POST['se_username'].' /GROUP:none /REALNAME:none /NOTE:none'."\n".'${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserPasswordSet '.$_POST['se_username'].' /PASSWORD:'.$_POST['se_password']."\n".'${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserExpiresSet '.$_POST['se_username'].' /EXPIRES:"${EXP} 00:00:00"'."\n".'sleep 2'."\n". PHP_EOL;
			file_put_contents('account_request.sh', $account_request, FILE_APPEND);
		}
	else 
		{
			$account_request= '#!/bin/bash'."\n".'# Script Author: _Dreyannz_'."\n"."\n".'TARGET="/usr/local/"'."\n".'EXP=$(date -d "CHANGE_ME_DAYS" +"%Y/%m/%d")'."\n".'HUB="CHANGE_ME_VHUB"'."\n".'PASSWORD="CHANGE_ME_PASSWORD"'."\n".'HUB=${HUB}'."\n".'PASSWORD=${PASSWORD}'."\n"."\n".'${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserCreate '.$_POST['se_username'].' /GROUP:none /REALNAME:none /NOTE:none'."\n".'${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserPasswordSet '.$_POST['se_username'].' /PASSWORD:'.$_POST['se_password']."\n".'${TARGET}vpnserver/vpncmd localhost /SERVER /PASSWORD:${PASSWORD} /HUB:${HUB} /CMD UserExpiresSet '.$_POST['se_username'].' /EXPIRES:"${EXP} 00:00:00"'."\n".'sleep 2'."\n". PHP_EOL;
			file_put_contents('account_request.sh', $account_request, FILE_APPEND);

		}


	$database= 'Username: '.$_POST['se_username']."\n".'Password: '.$_POST['se_password']."\n". PHP_EOL; 
	file_put_contents('Database.txt', $database, FILE_APPEND);

	echo '
		<html lang="en">
		<head>
			<title>SoftEther Request</title>
			<link rel="shortcut icon" type="image/x-icon" href="/logo.png" height="200" width"200">
			<meta charset="UTF-8">
			<meta name="author" content="_Dreyannz_">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="//use.fontawesome.com/releases/v5.0.10/css/all.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/hamburgers/0.9.3/hamburgers.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/animsition/4.0.2/css/animsition.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-css/1.4.6/select2-bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.min.css">
			<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.18.0/sweetalert2.min.css">
			<link rel="stylesheet" type="text/css" href="//ninjacdn.siteph.net/login/v1/css/util.css">
			<link rel="stylesheet" type="text/css" href="//ninjacdn.siteph.net/login/v1/css/main.css">
			<script src="//cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.18.0/sweetalert2.all.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/animsition/4.0.2/js/animsition.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.min.js"></script>
			<script src="//ninjacdn.siteph.net/login/v1/js/countdowntime.js"></script>
			<script src="//ninjacdn.siteph.net/login/v1/js/main.js"></script>
		</head>
		<body>
			<div>
				<div class="container-login100">
					<div class="wrap-login100">
						<div class="panel-heading p-b-48" align="center">
							<h4 class="panel-title">
								<img src="/logo.png" height="200" width"200" />
							</h4>
						</div>
						<form align="center">
							<div class="form-group">
								<center>
									<label>	
										<font color="red">
												Request Submitted
										</font>
									</label>
								</center>
							</div>
							<div class="form-group">
								<center>
									<label>
										Your Request Will Be Processed Atmost 3 Minutes
									</label>
								</center>
							</div>
							<div class="form-group">
								<center>
									<label>
										<font color="red">
											Dont Close This Window
										</font>
									</label>
								</center>
							</div>
							<div class="form-group">
								<center>
									<label>
										You Will Be Redirected To Your Account Details After This
									</label>
								</center>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		</body>
		</html>';
	header( "refresh:5;url=/my_account_$random_number.html" );

?>
